# Tantrum IPTV Editor

Minimilistic editor for IPTV list files.

Written in C#, using Visual Studio 2015