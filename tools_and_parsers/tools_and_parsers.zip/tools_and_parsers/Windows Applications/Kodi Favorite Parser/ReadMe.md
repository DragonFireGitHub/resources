# Kodi Favorites Parser (as an example app)

Use this to process favourites for creating Tantrum Youtube menu files. Use Kodi to go through and add Youtube content to your favourites, then this can parse it to build menus quickly and easily.

Written in C#, using Visual Studio 2015