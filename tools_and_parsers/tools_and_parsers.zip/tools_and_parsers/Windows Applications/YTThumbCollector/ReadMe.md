# Tantrum Youtube Thumbnail Collector

Gathers thumbnails for specific videos from Youtube for offline editing

Written in C#, using Visual Studio 2015